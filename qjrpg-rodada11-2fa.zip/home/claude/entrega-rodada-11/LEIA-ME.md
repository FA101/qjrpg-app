# Rodada 11 - 2FA por app autenticador (TOTP) - RF30-31

## Backend

### 1. Adicionar dependencia no pom.xml
```xml
<dependency>
    <groupId>dev.samstevens.totp</groupId>
    <artifactId>totp</artifactId>
    <version>1.7.1</version>
</dependency>
```
Se o Maven nao encontrar essa versao exata, procure "dev.samstevens.totp" no
site https://mvnrepository.com e use a versao mais recente listada la - a API usada
neste codigo (`DefaultSecretGenerator`, `DefaultCodeGenerator`, `DefaultCodeVerifier`,
`SystemTimeProvider`) e estavel entre versoes 1.x.

### 2. Arquivos NOVOS
- `auth/seguranca/TotpService.java`, `TotpServiceImpl.java`
- `auth/TotpController.java` (endpoints `/api/2fa/iniciar`, `/confirmar`, `/desativar`)
- `auth/dto/ValidarTotpRequest.java`

### 3. Arquivos para SOBRESCREVER
- `usuario/Usuario.java` (campos `totpSecret`, `totpAtivo`)
- `usuario/dto/UsuarioResponse.java` (novo campo `totpAtivo`)
- `auth/AuthService.java`, `AuthServiceImpl.java`, `AuthController.java`
- `auth/dto/AuthResponse.java` (novo campo `totpPendente`, `token` pode vir nulo)

### 4. Rodar os testes
`mvnw.cmd test` - preste atencao especial em `TotpServiceImplTest`, e a parte de maior
risco desta entrega (biblioteca externa que nao consegui compilar aqui).

### 5. Banco de dados
Colunas novas em `usuarios` (`totp_secret`, `totp_ativo`) sao nullable/com default - nao
deveria precisar recriar a tabela desta vez, mas se der erro parecido com o das rodadas
anteriores, o mesmo `DROP TABLE` de sempre resolve.

## Frontend
Nenhuma dependencia nova. Copie por cima:
- `features/auth/domain/usuario.dart` (nova classe `LoginResultado`), `auth_repository.dart`
- `features/auth/data/auth_api_repository.dart`
- `features/auth/presentation/auth_providers.dart`, `login_page.dart`, `perfil_page.dart`

## Como funciona o fluxo com 2FA ativo
1. Login normal (e-mail + codigo) continua igual.
2. Se a conta tiver 2FA ativo, a API retorna sem token (`totpPendente: true`) - o app
   mostra uma tela pedindo o codigo do autenticador.
3. Usuario digita o codigo do Google/Microsoft Authenticator - app chama
   `POST /api/auth/2fa/validar` e so ai recebe o token de verdade.

## Como ativar o 2FA (teste)
1. Logue normalmente (sem 2FA ainda).
2. Va em "Meu perfil" > "Ativar 2FA".
3. Aparece um segredo e uma URI `otpauth://...`. Adicione manualmente num app
   autenticador (a maioria tem uma opcao "inserir codigo manualmente" ao inves de
   escanear QR - nao geramos QR code nesta versao, de proposito, para nao arriscar mais
   uma biblioteca externa).
4. Digite o codigo de 6 digitos gerado pelo app e confirme.
5. Saia da conta (Sair) e faca login de novo - agora deve pedir o codigo do autenticador.

## Terminais para testar
**Terminal 1**: `cd api` > `.\mvnw.cmd spring-boot:run`
**Terminal 2**: `cd app` > `flutter analyze` > `flutter run -d web-server --web-port=8090`
**Terminal 3**: livre

## Status final do backlog do PRD
Com esta rodada, todo o backlog de autenticacao/seguranca planejavel em codigo puro esta
concluido. Restam fora do escopo, por limitacao real (nao por falta de esforco):
- **Push notification real**: precisa de projeto Firebase proprio seu.
- **Biometria**: so faz sentido num app nativo compilado (Android/iOS), nao em Flutter Web.
