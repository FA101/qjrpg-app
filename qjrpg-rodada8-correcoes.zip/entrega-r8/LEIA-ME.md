# Rodada 8 - Correcao do filtro de apelido (falso positivo) + minimo de caracteres

## Causa do problema
O filtro comparava se o apelido "continha" um termo proibido em qualquer parte da
palavra. Se sua lista tem termos curtos (3-4 letras), isso gera falso positivo em nomes
comuns (ex: um termo "ass" bloquearia "Cassio", "classico" etc. - chamado de "efeito
Scunthorpe"). Corrigido para comparar palavra INTEIRA, nao trecho.

## Arquivos para SOBRESCREVER (mesmo caminho de sempre)
- `api/src/main/java/com/qjrpg/api/moderacao/FiltroDePalavrasService.java`
- `api/src/main/java/com/qjrpg/api/auth/AuthServiceImpl.java` (agora exige apelido com
  no minimo 3 caracteres)
- `api/src/main/java/com/qjrpg/api/usuario/UsuarioController.java` (mesma regra ao editar
  o perfil depois)
- `app/lib/features/auth/presentation/login_page.dart` (rotulo do campo ajustado)
- `app/lib/features/auth/presentation/perfil_page.dart` (idem)

Depois de copiar, reinicie a API (`mvnw.cmd spring-boot:run`) e reinicie o Flutter
(`q` e rodar `flutter run -d web-server --web-port=8090` de novo).

## Como testar o que foi feito na Rodada 7 (checklist)

1. **Login com apelido**: crie uma conta nova (outro e-mail), confirme que o apelido com
   menos de 3 caracteres e recusado, e que um apelido normal funciona.
2. **Meu perfil**: no menu lateral, troque o apelido e ligue "Mostrar meu nome real" -
   salve e confira que nao da erro.
3. **Evento com data**: crie um evento novo, confirme que a data aparece na listagem.
4. **Mesa completa**: dentro de um evento, oferte uma mesa preenchendo sistema, titulo da
   aventura, sinopse, palavras-chave, observacoes, faixa etaria, vagas totais e
   reservadas. Confirme que a listagem mostra numero, sistema, mestre (nome/apelido) e
   vagas no formato "disponiveis/totais".
5. **Nomes de exibicao**: entre numa mesa, candidate-se e envie uma mensagem - confirme
   que aparece seu apelido (ou nome, se voce ligou a preferencia), nao mais um codigo.
6. **Denuncia**: clique no icone de bandeira ao lado de uma candidatura ou mensagem,
   envie um motivo. Para conferir do lado do back-end (ainda sem tela propria):
   ```powershell
   Invoke-RestMethod -Uri http://localhost:8080/api/denuncias -Headers @{Authorization="Bearer SEU_TOKEN"}
   ```
   (pegue o token no localStorage/no login, ou simplesmente confirme que o POST de
   denuncia nao deu erro - ja garante que a denuncia foi registrada).
7. **Enter no teclado**: confirme que Enter funciona em login, criar evento, ofertar
   mesa, enviar mensagem, criar tag, criar link.
