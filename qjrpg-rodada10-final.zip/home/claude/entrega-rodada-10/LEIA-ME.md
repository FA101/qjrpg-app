# Rodada 10 - Conta (suspender/excluir), notificacoes, menores de idade, relatorios, .ics

Sem dependencias novas (nem pom.xml, nem pubspec.yaml - o .ics usa dart:html, que ja vem
com o Flutter Web).

## Backend

### Arquivos para SOBRESCREVER
- `usuario/Usuario.java`, `UsuarioRepository.java`, `UsuarioController.java`
- `usuario/dto/UsuarioResponse.java`
- `auth/AuthService.java`, `AuthServiceImpl.java`, `AuthController.java`,
  `auth/dto/ConfirmarCodigoRequest.java`, `auth/dto/AuthResponse.java`
- `auth/seguranca/JwtAuthFilter.java` (bloqueia login de conta suspensa)
- `candidatura/CandidaturaServiceImpl.java` (agora notifica em conflito)
- `mesa/MesaServiceImpl.java` (notifica ao aprovar/recusar)
- `workshop/WorkshopServiceImpl.java` (idem)

### Arquivos NOVOS
- `usuario/dto/SuspenderRequest.java`, `NotificacoesUpdateRequest.java`
- `notificacao/` (pasta inteira - servico de notificacao interno, ver nota abaixo)
- `relatorio/` (pasta inteira - RF41/42)

### Nota importante: notificacao "push"
`NotificacaoServiceImpl` so registra em log (`[NOTIFICACAO] ...` no console da API) - nao
envia push de verdade. Enviar push real exige um projeto Firebase Cloud Messaging proprio
(com credenciais que so voce pode criar, vinculadas a sua conta Google). Quando tiver isso,
so essa uma classe precisa mudar - o resto do sistema ja depende so da interface.

### Migracao do banco (de novo)
A tabela `usuarios` ganhou varias colunas novas. Mais simples: apague e deixe recriar.
No pgAdmin4, Query Tool, no banco `qjrpg`:
```sql
DROP TABLE IF EXISTS denuncias, mensagens, candidaturas, mesas, produtos, workshops,
  conteudos_institucionais, links_uteis, tags, eventos, usuarios CASCADE;
```

## Frontend

### Arquivos para SOBRESCREVER
- `features/auth/domain/auth_repository.dart`, `usuario.dart` (sem mudanca real, so por completude)
- `features/auth/data/auth_api_repository.dart`
- `features/auth/presentation/auth_providers.dart`, `login_page.dart`, `perfil_page.dart`
- `features/evento/presentation/evento_detail_page.dart`, `evento_list_page.dart`
  (EventoDetailPage agora recebe o Evento inteiro, nao so id+nome - ajuste a chamada se
  voce tiver customizado algo)
- `features/produto/presentation/produto_list_page.dart` (Enter-to-submit)
- `features/workshop/presentation/workshop_list_page.dart` (Enter-to-submit)
- `core/widgets/app_drawer.dart` (itens Denuncias e Relatorios visiveis so p/ Admin/Moderador)

### Arquivos NOVOS
- `core/utils/ics_export.dart`
- `features/moderacao/` (se ainda nao tiver da rodada 9)
- `features/relatorio/` (pasta inteira)

## Terminais para testar
**Terminal 1**: `cd api` > `.\mvnw.cmd spring-boot:run`
**Terminal 2**: `cd app` > `flutter analyze` > `flutter run -d web-server --web-port=8090`
**Terminal 3**: livre

## Checklist de teste
1. Cadastro informando data de nascimento de menor (ex: ha 10 anos) - deve pedir e-mail
   do responsavel, e nao deixar prosseguir sem ele.
2. Logar com uma conta adulta que seja o e-mail do responsavel usado acima - em "Meu
   perfil" deve aparecer o vinculo pendente para confirmar.
3. Meu perfil: ligar/desligar notificacoes, suspender a propria conta por alguns dias,
   reativar, e (com uma conta de teste que voce nao precise mais) excluir a conta.
4. Como Admin/Moderador, abrir "Relatorios" no menu, filtrar mesas por tipo de jogo/mes/ano.
5. Dentro de um evento, clicar no icone de calendario na barra superior - deve baixar um
   arquivo `evento_qjrpg.ics`; abra com o Outlook/Google Calendar/Calendar para conferir.
6. Criar um conflito de candidatura (como fizemos antes) e conferir no console da API
   (Terminal 1) se aparece a linha `[NOTIFICACAO] ...`.
7. Enter no teclado agora funciona em Produto e Workshop tambem.

## O que NAO foi implementado (e por que)
- **Notificacao push real**: precisa de projeto Firebase seu (creditos/credenciais que so
  voce pode gerar). O gancho no codigo ja existe (`NotificacaoService`).
- **2FA por app autenticador (TOTP)**: e criptografia que eu nao conseguiria validar sem
  rodar os testes aqui, e essa rodada ja estava grande demais para arriscar. Fica pra uma
  rodada propria, focada, se voce quiser.
- **Biometria**: so faz sentido de verdade num app Android/iOS nativo compilado - no
  Flutter Web (que e como estamos testando) nao ha equivalente confiavel.
- Restricao fina de quem pode ver o proprio relatorio "frequencia de participacao" (RF42):
  o endpoint devolve os dados brutos filtrados; o calculo de frequencia por usuario ficou
  fora desta v1, por ser um agregado mais complexo.
