package com.qjrpg.api.auth.dto;
import com.qjrpg.api.usuario.PapelUsuario;
import java.util.UUID;
public record AuthResponse(String token, UUID usuarioId, String nome, String apelido, String email,
                            PapelUsuario papel, boolean vinculoResponsavelConfirmado) {}
