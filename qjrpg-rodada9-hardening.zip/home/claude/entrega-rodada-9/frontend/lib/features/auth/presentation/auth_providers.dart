import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/auth/auth_session.dart';
import '../../../core/network/dio_client.dart';
import '../data/auth_api_repository.dart';
import '../domain/auth_repository.dart';
import '../domain/usuario.dart';

final authRepositoryProvider = Provider<AuthRepository>((ref) => AuthApiRepository(DioClient.instance));

class AuthNotifier extends StateNotifier<Usuario?> {
  final AuthRepository _repository;
  AuthNotifier(this._repository) : super(null);

  Future<String> solicitarCodigo(String email) => _repository.solicitarCodigo(email);

  Future<void> confirmarCodigo(String email, String codigo, {String? nome, String? celular, String? apelido}) async {
    state = await _repository.confirmarCodigo(email, codigo, nome: nome, celular: celular, apelido: apelido);
  }

  /// Usado na reidratacao de sessao (F5) - define o usuario sem passar pelo fluxo de login.
  void definirUsuario(Usuario usuario) { state = usuario; }

  Future<void> sair() async {
    await AuthSession.limpar();
    state = null;
  }
}

final authNotifierProvider = StateNotifierProvider<AuthNotifier, Usuario?>((ref) {
  return AuthNotifier(ref.watch(authRepositoryProvider));
});

/// Roda uma vez, no início do app: tenta recuperar uma sessao salva.
/// Se o token salvo estiver invalido/expirado, limpa e deixa cair no login.
final sessaoInicialProvider = FutureProvider<void>((ref) async {
  await AuthSession.carregar();
  if (AuthSession.token == null) return;
  try {
    final usuario = await ref.read(authRepositoryProvider).buscarPerfil();
    ref.read(authNotifierProvider.notifier).definirUsuario(usuario);
  } catch (_) {
    await AuthSession.limpar();
  }
});
