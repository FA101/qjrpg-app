# Rodada 9 - Hardening de papeis, persistir sessao, tela de denuncias

## Backend

### Dependencia nova
Nenhuma no pom.xml. Mas precisamos adicionar `shared_preferences` no **pubspec.yaml**
do Flutter (ver frontend abaixo).

### Arquivos para SOBRESCREVER
- `com/qjrpg/api/evento/EventoController.java` (escrita restrita a ADMIN)
- `com/qjrpg/api/tag/TagController.java` (escrita restrita a ADMIN)
- `com/qjrpg/api/mesa/MesaController.java` (aprovar/recusar restrito a ADMIN/MODERADOR)
- `com/qjrpg/api/workshop/WorkshopController.java` (idem)
- `com/qjrpg/api/candidatura/CandidaturaService.java`,
  `CandidaturaServiceImpl.java`, `CandidaturaController.java`
  (aceitar/recusar agora exige ser o Game Master da mesa, ou Admin/Moderador)
- `com/qjrpg/api/usuario/Usuario.java` (2 metodos novos: definirPapel, definirAtivo)

### Arquivos NOVOS
- `com/qjrpg/api/usuario/dto/PapelUpdateRequest.java`
- `com/qjrpg/api/usuario/dto/AtivoUpdateRequest.java`
- `com/qjrpg/api/usuario/UsuarioAdminController.java` (RF22-25: promover/demover,
  suspender/ativar - endpoints `GET /api/usuarios`, `PATCH /api/usuarios/{id}/papel`,
  `PATCH /api/usuarios/{id}/ativo`)

### Como promover alguem a Admin/Moderador (por enquanto, via API)
```powershell
# listar usuarios (Admin ou Moderador)
Invoke-RestMethod -Uri http://localhost:8080/api/usuarios -Headers @{Authorization="Bearer SEU_TOKEN"}

# promover um usuario a MODERADOR (so Admin pode)
Invoke-RestMethod -Uri http://localhost:8080/api/usuarios/ID_DO_USUARIO/papel -Method PATCH -Headers @{Authorization="Bearer SEU_TOKEN"} -ContentType 'application/json' -Body '{"papel":"MODERADOR"}'
```
(Uma tela propria para isso fica pra depois - avise se quiser priorizar.)

## Frontend

### Dependencia nova
Abra `app/pubspec.yaml`, dentro de `dependencies:`, adicione:
```yaml
  shared_preferences: ^2.3.2
```
Rode `flutter pub get`.

### Arquivos para SOBRESCREVER
- `lib/core/auth/auth_session.dart` (agora persiste o token em disco)
- `lib/features/auth/domain/auth_repository.dart`, `data/auth_api_repository.dart`,
  `presentation/auth_providers.dart` (metodo novo: buscarPerfil, reidratacao de sessao)
- `lib/main.dart` (espera a reidratacao antes de decidir Login x App)
- `lib/core/widgets/app_drawer.dart` (item "Denuncias pendentes" so para Admin/Moderador;
  "Sair" agora e assincrono)

### Arquivos NOVOS
- `lib/features/moderacao/` (pasta inteira: domain, data, presentation - tela de
  denuncias pendentes)

## Terminais necessarios para testar

**Terminal 1 - API**: `cd api` > `.\mvnw.cmd spring-boot:run`
**Terminal 2 - App**: `cd app` > `flutter pub get` > `flutter analyze` > `flutter run -d web-server --web-port=8090`
**Terminal 3 - livre**

## Checklist de teste desta rodada
1. Login normal, dar F5 na pagina - deve continuar logado (nao voltar pro login).
2. Como usuario comum, tentar criar evento/tag direto pela API (deve dar 403 Forbidden).
3. Como Admin (seu e-mail configurado em app.admin-emails), criar evento/tag funciona.
4. Tentar aceitar uma candidatura de uma mesa que NAO e sua - deve dar erro. Aceitar a
   sua propria mesa funciona.
5. Promover um segundo usuario a Moderador via API (comando acima), logar com ele,
   conferir que aparece "Denuncias pendentes" no menu e que ele consegue aprovar/recusar
   mesas e workshops, mas nao criar eventos/tags novas.
6. Denunciar um apelido (bandeira), depois no menu "Denuncias pendentes" marcar como
   Procedente - o usuario denunciado deve perder o apelido (proximo GET /usuarios/me
   mostra apelido nulo).

## Backlog restante do PRD (ainda nao implementado, para voce priorizar)
- Suspensao/exclusao de conta pelo proprio usuario (RF38/39), notificacoes push (RF37)
- Menores de idade e vinculo com responsavel (RF34-36)
- 2FA (TOTP) e biometria (RF30-32)
- Relatorios administrativos consolidados (RF41/42)
- Exportar evento para calendario do dispositivo, .ics (RF43)
- Enter-to-submit em Produto/Workshop (baixa prioridade, nao pedido ainda)
