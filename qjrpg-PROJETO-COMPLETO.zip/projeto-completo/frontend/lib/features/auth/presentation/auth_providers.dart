import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/auth/auth_session.dart';
import '../../../core/network/dio_client.dart';
import '../data/auth_api_repository.dart';
import '../domain/auth_repository.dart';
import '../domain/usuario.dart';

final authRepositoryProvider = Provider<AuthRepository>((ref) => AuthApiRepository(DioClient.instance));

class AuthNotifier extends StateNotifier<Usuario?> {
  final AuthRepository _repository;
  AuthNotifier(this._repository) : super(null);

  Future<String> solicitarCodigo(String email) => _repository.solicitarCodigo(email);

  /// Retorna true se o 2FA estiver pendente (login ainda nao concluido).
  Future<bool> confirmarCodigo(String email, String codigo,
      {String? nome, String? celular, String? apelido,
      String? dataNascimento, String? sexo, String? responsavelEmail}) async {
    final resultado = await _repository.confirmarCodigo(email, codigo,
        nome: nome, celular: celular, apelido: apelido,
        dataNascimento: dataNascimento, sexo: sexo, responsavelEmail: responsavelEmail);
    if (resultado.totpPendente) return true;
    state = resultado.usuario;
    return false;
  }

  Future<void> validarSegundoFator(String email, String codigo) async {
    state = await _repository.validarSegundoFator(email, codigo);
  }

  void definirUsuario(Usuario usuario) { state = usuario; }

  Future<void> sair() async {
    await AuthSession.limpar();
    state = null;
  }
}

final authNotifierProvider = StateNotifierProvider<AuthNotifier, Usuario?>((ref) {
  return AuthNotifier(ref.watch(authRepositoryProvider));
});

final sessaoInicialProvider = FutureProvider<void>((ref) async {
  await AuthSession.carregar();
  if (AuthSession.token == null) return;
  try {
    final usuario = await ref.read(authRepositoryProvider).buscarPerfil();
    ref.read(authNotifierProvider.notifier).definirUsuario(usuario);
  } catch (_) {
    await AuthSession.limpar();
  }
});
