import 'usuario.dart';

abstract class AuthRepository {
  Future<String> solicitarCodigo(String email);
  Future<LoginResultado> confirmarCodigo(String email, String codigo,
      {String? nome, String? celular, String? apelido,
      String? dataNascimento, String? sexo, String? responsavelEmail});
  Future<Usuario> validarSegundoFator(String email, String codigo);
  Future<Usuario> buscarPerfil();
}
