// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;

void baixarIcsDoEvento({
  required String nome,
  required String data,
  required String local,
  String? horaInicio,
  String? horaFim,
}) {
  final dataCompacta = data.replaceAll('-', '');
  final inicio = (horaInicio ?? '09:00:00').replaceAll(':', '').substring(0, 6);
  final fim = (horaFim ?? '22:00:00').replaceAll(':', '').substring(0, 6);
  final agora = DateTime.now().toUtc().toIso8601String().replaceAll(RegExp(r'[-:]'), '').split('.').first;

  final conteudo = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//QJRPG//App//PT',
    'BEGIN:VEVENT',
    'UID:${DateTime.now().microsecondsSinceEpoch}@qjrpg.app',
    'DTSTAMP:${agora}Z',
    'DTSTART:${dataCompacta}T$inicio',
    'DTEND:${dataCompacta}T$fim',
    'SUMMARY:$nome',
    'LOCATION:$local',
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');

  final blob = html.Blob([conteudo], 'text/calendar');
  final url = html.Url.createObjectUrlFromBlob(blob);
  html.AnchorElement(href: url)
    ..setAttribute('download', 'evento_qjrpg.ics')
    ..click();
  html.Url.revokeObjectUrl(url);
}
