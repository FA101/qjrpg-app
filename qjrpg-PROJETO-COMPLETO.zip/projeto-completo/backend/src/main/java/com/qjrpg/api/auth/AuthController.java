package com.qjrpg.api.auth;

import com.qjrpg.api.auth.dto.*;
import com.qjrpg.api.usuario.Usuario;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) { this.authService = authService; }

    @PostMapping("/solicitar-codigo")
    public SolicitarCodigoResponse solicitarCodigo(@Valid @RequestBody SolicitarCodigoRequest r) {
        String codigo = authService.solicitarCodigo(r.email());
        return new SolicitarCodigoResponse(
                "Codigo gerado (modo desenvolvimento, sem envio real de e-mail ainda)", codigo);
    }

    @PostMapping("/confirmar-codigo")
    public AuthResponse confirmarCodigo(@Valid @RequestBody ConfirmarCodigoRequest r) {
        AuthResultado resultado = authService.confirmarCodigo(r.email(), r.codigo(), r.nome(), r.celular(),
                r.apelido(), r.dataNascimento(), r.sexo(), r.responsavelEmail());
        Usuario u = resultado.usuario();
        boolean totpPendente = resultado.token() == null;
        return new AuthResponse(resultado.token(), u.getId(), u.getNome(), u.getApelido(), u.getEmail(),
                u.getPapel(), u.isVinculoResponsavelConfirmado(), totpPendente);
    }

    @PostMapping("/2fa/validar")
    public AuthResponse validarTotp(@Valid @RequestBody ValidarTotpRequest r) {
        AuthResultado resultado = authService.validarSegundoFator(r.email(), r.codigo());
        Usuario u = resultado.usuario();
        return new AuthResponse(resultado.token(), u.getId(), u.getNome(), u.getApelido(), u.getEmail(),
                u.getPapel(), u.isVinculoResponsavelConfirmado(), false);
    }

    @GetMapping("/me")
    public Map<String, Object> me(Authentication authentication) {
        return Map.of(
                "usuarioId", authentication.getPrincipal().toString(),
                "papel", authentication.getAuthorities().toString());
    }
}
