package com.qjrpg.api.usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
public interface UsuarioRepository extends JpaRepository<Usuario, UUID> {
    Optional<Usuario> findByEmail(String email);
    Optional<Usuario> findByApelido(String apelido);
    List<Usuario> findByResponsavelEmailAndVinculoResponsavelConfirmadoFalse(String responsavelEmail);
}
