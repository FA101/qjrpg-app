# Projeto QJRPG - Entrega consolidada (substitui as 11 rodadas anteriores)

Este pacote e a arvore COMPLETA e ja mesclada de tudo que foi construido, nas 11 rodadas.
Se voce ainda nao integrou nada, comece do zero com este pacote - e mais seguro do que
seguir os 11 LEIA-MEs manualmente. Se voce ja integrou parte das rodadas anteriores, pode
usar este pacote para SOBRESCREVER tudo de uma vez (copiar por cima, aceitando substituir).

## Passo a passo do zero

### 1. Backend
1. Gere o projeto base em start.spring.io (Maven, Java 21, Spring Boot 3.x, dependencias:
   Spring Web, Spring Data JPA, PostgreSQL Driver, Validation).
2. Copie `backend/src` deste pacote para dentro do projeto gerado, substituindo tudo.
3. No `pom.xml`, dentro de `<dependencies>`, adicione:
   ```xml
   <dependency>
       <groupId>org.springframework.boot</groupId>
       <artifactId>spring-boot-starter-security</artifactId>
   </dependency>
   <dependency>
       <groupId>io.jsonwebtoken</groupId>
       <artifactId>jjwt-api</artifactId>
       <version>0.12.6</version>
   </dependency>
   <dependency>
       <groupId>io.jsonwebtoken</groupId>
       <artifactId>jjwt-impl</artifactId>
       <version>0.12.6</version>
       <scope>runtime</scope>
   </dependency>
   <dependency>
       <groupId>io.jsonwebtoken</groupId>
       <artifactId>jjwt-jackson</artifactId>
       <version>0.12.6</version>
       <scope>runtime</scope>
   </dependency>
   <dependency>
       <groupId>dev.samstevens.totp</groupId>
       <artifactId>totp</artifactId>
       <version>1.7.1</version>
   </dependency>
   ```
4. No `application.yml`, garanta que tem:
   ```yaml
   spring:
     application:
       name: qjrpg-api
     datasource:
       url: jdbc:postgresql://localhost:5432/qjrpg
       username: postgres
       password: SUA_SENHA_AQUI
     jpa:
       hibernate:
         ddl-auto: update
       show-sql: true

   server:
     port: 8080

   app:
     jwt:
       secret: "troque-este-segredo-antes-de-qualquer-uso-real-0123456789"
       expiracao-dias: 30
     admin-emails: "SEU_EMAIL_AQUI@exemplo.com"
   ```
5. No pgAdmin4, crie (ou recrie do zero, se ja existia) o banco `qjrpg`.
6. `mvnw.cmd test` - devem passar 13 classes de teste, incluindo `JwtServiceImplTest` e
   `TotpServiceImplTest` (as duas partes de maior risco, por dependerem de bibliotecas
   externas que eu nao consigo compilar no meu lado).
7. `mvnw.cmd spring-boot:run`.

### 2. Frontend
1. `flutter create app`.
2. Copie `frontend/lib` deste pacote para dentro de `app/lib`, substituindo tudo.
3. No `pubspec.yaml`, dentro de `dependencies:`, adicione:
   ```yaml
   flutter_riverpod: ^2.5.1
   dio: ^5.5.0
   intl: ^0.19.0
   shared_preferences: ^2.3.2
   ```
4. `flutter pub get`
5. `flutter analyze` (so devem aparecer avisos leves de estilo, sem erros)
6. `flutter run -d web-server --web-port=8090`
7. Abra `http://localhost:8090` manualmente no navegador.

## Terminais necessarios para testar

**Terminal 1 (API)**: `cd api` > `.\mvnw.cmd spring-boot:run`
**Terminal 2 (App)**: `cd app` > `flutter run -d web-server --web-port=8090`
**Terminal 3 (livre)**: comandos avulsos, git, Invoke-RestMethod

## O que este pacote cobre (visao geral)

**Back-end (14 modulos)**: Evento, Mesa, Candidatura, Produto, Workshop, Mensagem, Tag,
Link Util, Conteudo Institucional, Usuario, Auth (login sem senha + 2FA TOTP), Moderacao
(filtro de palavras + denuncias), Notificacao (interna, log), Relatorio.

**Front-end**: mesmos modulos, navegacao hierarquica (Eventos > Mesas > Candidaturas/
Mensagens), formularios completos, autenticacao com sessao persistente, tela de perfil
(apelido, 2FA, notificacoes, suspender/excluir conta), relatorios com filtros, exportacao
para calendario (.ics).

## O que fica de fora, por limitacao real
- Push notification de verdade (precisa de projeto Firebase seu).
- Biometria (so faz sentido em app nativo compilado, nao em Flutter Web).

## Uma correcao de organizacao que fiz nesta consolidacao
Removi um arquivo orfao (`EventoNaoEncontradoException.java`, da Rodada 1) que deveria
ter sido apagado na Rodada 2 e que, por engano, poderia ter sobrevivido no seu projeto se
voce nao apagou manualmente na epoca. Confira se ele ainda existe no seu projeto real e
apague se sim - nao quebra nada, mas e codigo morto.
